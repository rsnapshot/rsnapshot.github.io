See LICENSE.txt for licensing information
See INSTALL.txt for installation instructions
See TODO.txt for more to come


For latest documentation type:

$perldoc rsnapshotDB.pl
or
$perldoc rsnapshotDB
or
$perldoc /path/to/rsnapshotDB.pl


Trouble Shooting:
mailing list: rsnapshot-request@lists.sf.net
subject: "subscribe"

Other Info:
Author: Anthony Ettinger
Email: aettinger<-rm-@-spam->sdsualumni.org
Blog: http://www.chovy.com
