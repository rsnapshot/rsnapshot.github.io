This directory contains legacy HOWTO documentation, a make file for building the
documentation in a number of formats, and a copy of the build output files. The
most up to date source of documentation is the *rsnapshot man page*.

To build the documentation on Debian you need to install the following packages:

    xsltproc
    docbook-xsl
    docbook-xml
    fop
    docbook2x
    texinfo

Then run `make`.
